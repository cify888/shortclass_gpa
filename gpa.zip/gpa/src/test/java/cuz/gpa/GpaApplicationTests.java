package cuz.gpa;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GpaApplicationTests {

	@Test
	void contextLoads() {
	}

}
